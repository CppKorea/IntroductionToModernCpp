#include <iostream>

void PrintMessage();

int main() {
	// PrintMessage() �Լ��� ȣ��
	PrintMessage();

	return 0;
}

void PrintMessage() {
	std::cout << "Hi, I'm Your First Function\n";
}