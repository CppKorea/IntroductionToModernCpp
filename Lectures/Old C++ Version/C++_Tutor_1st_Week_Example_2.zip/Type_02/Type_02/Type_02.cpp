#include <iostream>

int main() {
	std::cout << "short int : " << sizeof(short int) << " Bytes\n";
	std::cout << "unsigned short int : " << sizeof(unsigned short int) << " Bytes\n";
	std::cout << "int : " << sizeof(int) << " Bytes\n";
	std::cout << "unsigned int : " << sizeof(unsigned int) << " Bytes\n";
	std::cout << "long int : " << sizeof(long int) << " Bytes\n";
	std::cout << "unsigned long int : " << sizeof(unsigned long int) << " Bytes\n";

	return 0;
}