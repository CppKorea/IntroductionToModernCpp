#ifndef HEADER_IMPL_11
#define HEADER_IMPL_11

struct Point {
	int x, y;
};

#endif