#include "Header_Impl_11.h"
#include "Header_Impl_11.h"

int main() {
	Point pt = {3, 4};

	return 0;
}