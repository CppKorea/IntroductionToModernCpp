#include "Header_Impl_10.h"
#include "Header_Impl_10.h"

int main() {
	Point pt = {3, 4};

	return 0;
}