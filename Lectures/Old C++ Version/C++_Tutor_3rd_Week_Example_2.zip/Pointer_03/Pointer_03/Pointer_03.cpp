int main() {
	// int Ÿ��
	int i = 300;
	int* pi = &i;

	// char Ÿ��
	char c = 'C';
	char* pc = &c;

	// float Ÿ��
	float f = 700.5f;
	float* pf = &f;

	// bool Ÿ��
	bool b = true;
	bool* pb = &b;

	// short int Ÿ��
	short int s = 456;
	short int* ps = &s;

	return 0;
}